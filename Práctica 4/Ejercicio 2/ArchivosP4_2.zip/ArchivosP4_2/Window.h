#pragma once
#include<stdio.h>
#include<glew.h>
#include<glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	bool getShouldClose() {
		return  glfwWindowShouldClose(mainWindow);}
	bool* getsKeys() { return keys; }
	GLfloat getXChange();
	GLfloat getYChange();
	void swapBuffers() { return glfwSwapBuffers(mainWindow); }
	GLfloat getrotay() { return rotay; }
	GLfloat getrotax() { return rotax; }
	GLfloat getrotaz() { return rotaz; }
	GLfloat getPata1_1() { return pata1_1; }
	GLfloat getPata1_2() { return pata1_2; }
	GLfloat getPata2_1() { return pata2_1; }
	GLfloat getPata2_2() { return pata2_2; }
	GLfloat getPata3_1() { return pata3_1; }
	GLfloat getPata3_2() { return pata3_2; }
	GLfloat getPata4_1() { return pata4_1; }
	GLfloat getPata4_2() { return pata4_2; }
	GLfloat getOrejaIzq() { return orejaIzq; }
	GLfloat getOrejaDer() { return orejaDer; }




	~Window();
private: 
	GLFWwindow *mainWindow;
	GLint width, height;
	GLfloat rotax,rotay,rotaz, pata1_1, pata1_2, pata2_1, pata2_2, pata3_1, pata3_2, pata4_1, pata4_2, orejaDer, orejaIzq;
	bool keys[1024];
	GLint bufferWidth, bufferHeight;
	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	bool mouseFirstMoved;
	void createCallbacks();
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);
};

